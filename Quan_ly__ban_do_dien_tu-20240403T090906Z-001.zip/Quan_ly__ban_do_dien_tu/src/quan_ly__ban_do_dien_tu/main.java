package quan_ly__ban_do_dien_tu;

import java.io.FileNotFoundException;

public class main {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		Menu list = new Menu();
		list.menu();		
	}		
}
