package quan_ly__ban_do_dien_tu;

public interface Imenu {
	void menu();
}
